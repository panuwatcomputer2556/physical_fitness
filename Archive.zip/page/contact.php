<div class="card mb-12">
                                <img class="card-img-top" src="https://www.qrcode-monkey.com/img/default-preview-qr.svg"  width="400px" height="400px">
                                <div class="card-body">
                                  
                                <center><h1>Scan Qrcode</h1></center>
                                </div>
</div>