<?php
$type='Type1';
$name='KoHmu2';
$desc=array('Ascent'=>830,'Descent'=>-293,'CapHeight'=>402,'Flags'=>32,'FontBBox'=>'[-382 -219 964 830]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-100;
$ut=50;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>222,'!'=>342,'"'=>584,'#'=>616,'$'=>616,'%'=>848,'&'=>713,'\''=>365,'('=>334,')'=>334,'*'=>365,'+'=>592,
	','=>308,'-'=>252,'.'=>216,'/'=>378,'0'=>431,'1'=>431,'2'=>431,'3'=>431,'4'=>431,'5'=>431,'6'=>431,'7'=>431,'8'=>431,'9'=>431,':'=>216,';'=>216,'<'=>415,'='=>415,'>'=>415,'?'=>362,'@'=>415,'A'=>222,
	'B'=>222,'C'=>222,'D'=>222,'E'=>222,'F'=>222,'G'=>222,'H'=>707,'I'=>222,'J'=>222,'K'=>736,'L'=>222,'M'=>736,'N'=>222,'O'=>736,'P'=>222,'Q'=>222,'R'=>222,'S'=>222,'T'=>222,'U'=>616,'V'=>222,'W'=>222,
	'X'=>222,'Y'=>222,'Z'=>222,'['=>244,'\\'=>378,']'=>244,'^'=>415,'_'=>322,'`'=>218,'a'=>222,'b'=>222,'c'=>222,'d'=>222,'e'=>222,'f'=>222,'g'=>222,'h'=>707,'i'=>222,'j'=>222,'k'=>736,'l'=>222,'m'=>736,
	'n'=>222,'o'=>736,'p'=>222,'q'=>222,'r'=>222,'s'=>222,'t'=>222,'u'=>616,'v'=>222,'w'=>222,'x'=>222,'y'=>222,'z'=>222,'{'=>244,'|'=>378,'}'=>244,'~'=>415,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>222,chr(161)=>736,chr(162)=>616,chr(163)=>616,chr(164)=>736,chr(165)=>736,chr(166)=>736,chr(167)=>616,chr(168)=>616,chr(169)=>736,chr(170)=>616,chr(171)=>616,chr(172)=>831,chr(173)=>830,chr(174)=>736,chr(175)=>736,
	chr(176)=>736,chr(177)=>612,chr(178)=>829,chr(179)=>1009,chr(180)=>736,chr(181)=>736,chr(182)=>736,chr(183)=>612,chr(184)=>736,chr(185)=>770,chr(186)=>736,chr(187)=>736,chr(188)=>976,chr(189)=>976,chr(190)=>976,chr(191)=>976,chr(192)=>736,chr(193)=>736,chr(194)=>736,chr(195)=>736,chr(196)=>736,chr(197)=>615,
	chr(198)=>736,chr(199)=>616,chr(200)=>736,chr(201)=>736,chr(202)=>615,chr(203)=>707,chr(204)=>976,chr(205)=>736,chr(206)=>736,chr(207)=>363,chr(208)=>385,chr(209)=>1,chr(210)=>616,chr(211)=>616,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>382,chr(224)=>202,chr(225)=>360,chr(226)=>736,chr(227)=>736,chr(228)=>736,chr(229)=>616,chr(230)=>736,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>448,chr(240)=>431,chr(241)=>431,
	chr(242)=>431,chr(243)=>431,chr(244)=>431,chr(245)=>431,chr(246)=>431,chr(247)=>431,chr(248)=>431,chr(249)=>431,chr(250)=>521,chr(251)=>978,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='kohmu2.z';
$size1=6005;
$size2=31470;
?>
